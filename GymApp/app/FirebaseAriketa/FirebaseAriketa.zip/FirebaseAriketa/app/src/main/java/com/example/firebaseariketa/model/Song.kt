package com.example.firebaseariketa.model

data class Song (
    val name:String,
    val duration: Int
){
}